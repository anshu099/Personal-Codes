// Singleton
function Book(isbn, title, price){
	this.getIsbn = function() {
		return isbn;
	};
	this.getPrice = function() {
		return price;
	};
	this.getTitle = function(){
		return title;
	}
}

Library = (function() {
	var instance;
	function init(){
		var books = [];
		return {
			add:function(book){
				books.push(book);
			},
			list:function(){
				return books;
			},
			search:function(isbn){
				for(var i=0; i<books.length; i++)
					if(books[i].getIsbn() == isbn)
						return books[i];
			}
		}
	}
	return {
		getInstance: function(){
			if(!instance)
				instance = init();
			return instance;
		}
	}
})();

library = Library.getInstance();
library.add(new Book(1, 'JavaScript', 100));
library.add(new Book(2, 'Design Patterns', 250));
console.log(library.search(1).getIsbn());
console.log(library.list());