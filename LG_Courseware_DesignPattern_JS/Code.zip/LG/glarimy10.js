// Mediator with pub/sub
EventManager = (function(){
	var instance;
	function init(){
		var topics = {};
		return {
			publish: function(message, topic){
				if(topics[topic] != null)
					for(var i=0; i<topics[topic].length; i++){
						topics[topic][i].apply(null, [message]);
				}
			},
			subscribe: function(topic, fn){
				if(topics[topic] == null)
					topics[topic] = [fn];
				else
					topics[topic].push(fn);
			},
			unsubscribe: function(topic){
				// TODO
				topics[topic] = null;
			}
		}
	}
	return {
		getInstance : function(){
			if(!instance)
				instance = init();
			return instance;
		}
	}
})();

EventManager.getInstance().subscribe('cricket', function(message){
	console.log("received message on circket")
});
EventManager.getInstance().subscribe('cricket', function(message){
	console.log("received message on circket: " + message);
});

EventManager.getInstance().publish('new committee formed', 'cricket');