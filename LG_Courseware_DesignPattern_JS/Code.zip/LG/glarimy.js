// Layer - 1 
Glarimy = (function(){
	return {
		js: {
			klass: {
				define: function(name, config){
					function Proto(config){
						for(c in config){
							this[c] = config[c];
						}
					}
					window[name] = Proto;
				},
				create: function(name, data){
					var o = new window[name](data);
					return o;
				},
				extend: function(parent, child, config){
					function Proto(data){
						for(c in config){
							this[c] = config[c];
						}	
					}
					window[child] = Proto;
					window[child].prototype = new window[name]({});
				}
			}
		}
	}
})();

// Layer - 2 
Glarimy.js.klass.define("Person", {
	name: 'string',
	phone: 'int',
	city: 'string'
});

var p = Glarimy.js.klass.create("Person", {
	name: 'Krishna',
	phone: 12345
});

console.log(p);

Glarimy.js.klass.extend("Employee", {
	salary: 1000
});

var e = Glarimy.js.klass.create("Employee", {
	salary: 1250
});

console.log(e);