// Facade
function Book(isbn, title, price){
	this.getIsbn = function() {
		return isbn;
	};
	this.getPrice = function() {
		return price;
	};
	this.getTitle = function(){
		return title;
	}
}

Xhr = (function(){
	var instance;
	function init(){
		return {
			get: function(config){
				//ajax get request using config
				console.log('ajax get');
			},
			post: function(config){
				//ajax post request using config
				console.log('ajax post');
			}
		}
	}
	return {
		getInstance : function(){
			if(!instance)
				instance = init();
			return instance;
		}
	}
})();

Library = (function() {
	var instance;
	function init(){
		var books = [];
		Xhr.getInstance().get({
			url: '/book',
			success: function(data){
				books = JSON.parse(data);
			}
		});
		return {
			add:function(book){
				books.push(book);
				Xhr.getInstance().post({
					url: 'book',
					data: book
				});
			},
			list:function(){
				return books;
			},
			search:function(isbn){
				for(var i=0; i<books.length; i++)
					if(books[i].getIsbn() == isbn)
						return books[i];
			}
		}
	}
	return {
		getInstance: function(){
			if(!instance)
				instance = init();
			return instance;
		}
	}
})();

library = Library.getInstance();
library.add(new Book(1, 'JavaScript', 100));
library.add(new Book(2, 'Design Patterns', 250));
console.log(library.search(1).getIsbn());
console.log(library.list());