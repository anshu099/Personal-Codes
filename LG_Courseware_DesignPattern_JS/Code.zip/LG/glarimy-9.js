// Template
function Book(isbn, title, price){
	this.getIsbn = function() {
		return isbn;
	};
	this.getPrice = function() {
		return price;
	};
	this.getTitle = function(){
		return title;
	};
	this.compare = function(other){
		if(isbn > other.getIsbn())
			return true;
		else
			return false;
	}

}

function ArrayCollection(){
	this.items = [];
	this.each = function(fn){
		for(var i=0; i<this.items.length; i++)
			fn.apply(null, [this.items[i]]);
	}
}

Library = (function() {
	var instance;
	function init(){
		var books = new ArrayCollection();
		return {
			add:function(book){
				books.items.push(book);
			},
			list:function(){
				return books;
			},
			search:function(isbn){
				for(var i=0; i<books.items.length; i++)
					if(books.items[i].getIsbn() == isbn)
						return books.items[i];
			}
		}
	}
	return {
		getInstance: function(){
			if(!instance)
				instance = init();
			return instance;
		}
	}
})();

function Sorter(){
	this.sort = function(list){
		for(var i=0; i<list.length; i++)
			for(var j=i; j<list.length-1; j++)
				if(list[j].compare(list[j+1])){
					var temp = list[j+1];
					list[j+1] = list[j];
					list[j] = temp;
				}
		var sortedList = new ArrayCollection();
		sortedList.items = list;
		return sortedList;
	}
}

function SortableLibrary(library){	
	this.add =  function(book){
		return library.add(book);
	}
	this.list = function(){
		return library.list();
	}
	this.search = function(isbn){
		return library.search(isbn);
	}
	this.sort = function(){
		var sorter = new Sorter();
		sorter.sort(this.list().items);
	}
}

library = Library.getInstance();
library.add(new Book(12, 'JavaScript', 100));
library.add(new Book(2, 'Design Patterns', 250));
console.log(library.search(12).getIsbn());
library.list().each(function(book){
	console.log(book.getIsbn() + " " + book.getTitle() + " " + book.getPrice());
})
sortableLibrary = new SortableLibrary(library);
console.log(sortableLibrary.sort());
sortableLibrary.sort().each(function(book){
	console.log(book.getIsbn() + " " + book.getTitle() + " " + book.getPrice());
})