// Prototype
function Book(isbn, title, price, author){
	this.getIsbn = function() {
		return isbn;
	};
	this.getPrice = function() {
		return price;
	};
	this.getTitle = function(){
		return title;
	};
	this.getAuthor = function(){
		return author;
	};
	this.setIsbn = function(isbn){
		isbn = isbn;
	};
	this.setTitle = function(title){
		title = title;
	}
	this.setAuthor = function(author){
		author = author;
	};
	this.setPrice = function(price){
		price = price;
	};
}

Library = (function() {
	var instance;
	function init(){
		var books = [];
		return {
			add:function(book){
				books.push(book);
			},
			list:function(){
				return books;
			},
			search:function(isbn){
				for(var i=0; i<books.length; i++){
					if(books[i].getIsbn() == isbn)
						return books[i];
				}
			}
		}
	}
	return {
		getInstance: function(){
			if(!instance)
				instance = init();
			return instance;
		}
	}
})();

BookFactory = (function(){
	var proto = new Book(10, "Krishna Title", 100, "Krishna");
	return {
		get: function(isbn, title){
			var book = Object.create(proto, {
				isbn: {
					value: isbn,
					enumerable: true
				},
				title: {
					value: title,
					enumerable: true
				}
			});
			return book;
		}
	}
})();

LibraryFactory = {}
LibraryFactory.get = function(){
	return Library.getInstance();
}

library = LibraryFactory.get();
book1 = BookFactory.get(1, "ECMA");
book2 = BookFactory.get(2, "Chome");
book3 = BookFactory.get(3, "Mozilla");

library.add(book1);
library.add(book2);
library.add(book3);

console.log(library.search(1));
console.log(library.search(2));
console.log(library.search(3));
console.log(library.list());