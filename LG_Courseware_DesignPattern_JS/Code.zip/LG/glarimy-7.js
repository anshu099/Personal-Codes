// Iterator
function Book(isbn, title, price){
	this.getIsbn = function() {
		return isbn;
	};
	this.getPrice = function() {
		return price;
	};
	this.getTitle = function(){
		return title;
	}
}

function ArrayCollection(){
	this.items = [];
	this.each = function(fn){
		for(var i=0; i<this.items.length; i++)
			fn.apply(null, [this.items[i]]);
	}
}

Library = (function() {
	var instance;
	function init(){
		var books = new ArrayCollection();
		return {
			add:function(book){
				books.items.push(book);
			},
			list:function(){
				return books;
			},
			search:function(isbn){
				for(var i=0; i<books.items.length; i++)
					if(books.items[i].getIsbn() == isbn)
						return books.items[i];
			}
		}
	}
	return {
		getInstance: function(){
			if(!instance)
				instance = init();
			return instance;
		}
	}
})();

library = Library.getInstance();
library.add(new Book(1, 'JavaScript', 100));
library.add(new Book(2, 'Design Patterns', 250));
console.log(library.search(1).getIsbn());
library.list().each(function(book){
	console.log(book.getIsbn() + " " + book.getTitle() + " " + book.getPrice());
})