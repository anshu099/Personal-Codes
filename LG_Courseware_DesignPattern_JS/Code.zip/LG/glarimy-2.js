// Factory pattern
function Book(isbn, title, price){
	this.getIsbn = function() {
		return isbn;
	};
	this.getPrice = function() {
		return price;
	};
	this.getTitle = function(){
		return title;
	}
}

function Library(){
	var books = [];
	this.add = function(book){
		books.push(book);
	}
	this.list = function(){
		return books;
	}
	this.search = function(isbn){
		for(var i=0; i<books.length; i++)
			if(books[i].getIsbn() == isbn)
				return books[i];
	}

}

LibraryFactory = {}

LibraryFactory.get = function(){
	return new Library();
}

//library = new Library();
library = LibraryFactory.get();
library.add(new Book(1, 'JavaScript', 100));
library.add(new Book(2, 'Design Patterns', 250));
console.log(library.search(1).getIsbn());
console.log(library.list());